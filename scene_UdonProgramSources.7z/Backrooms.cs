﻿
using UdonSharp;
using UnityEngine;
using VRC.SDKBase;
using VRC.Udon;
using System;

public class Backrooms : UdonSharpBehaviour
{
    // Parameters
    public int gridSideSize = 100;

    public double minRowColSize = 0.8;
    public double maxRowColSize = 5; 

    private double horizontalRectangleProbability = 0.5;
    public double thickRectangleProbability = 0.1;
    public int thickRectangleMaxGridNum = 4;

    public int numRectangles = 30;

    public GameObject floorTile;
    public GameObject ceilingTile;
    public GameObject wallTile;
    public GameObject skirtingBoardTile;
    private double skirtingBoardThickness = 0.006;
    public GameObject lightUnit;
    public double spaceBetweenLights = 5;

    public GameObject emptyGameObject;

    // ----------------------------------------------------------
    // Constants
    private string North = "N";
    private string South = "S";
    private string East = "E";
    private string West = "W";

    // ----------------------------------------------------------
    // Shared variables
    private Grid currentGrid;

    private double[] columns;
    private int numCols;
    private double[] rows;
    private int numRows;
    private bool[][] rectangles;
    private void InitializeGrid()
    {
        // Generates a grid of "gridSideSize" x "gridSideSize" and stores it in "columns", "rows", and "rectangles"

        // This grid consists of a variable-size rows and columns, as well as a set of traversable elements in that grid
        // Each row or column must be at least "minRowColSize" and at most "maxRowColSize"
        // (Kind of. They may be slightly smaller or larger than that in order to normalize them.)
        
        // The "columns" and "rows" arrays store the widths of the columns and rows
        // The "rectangles" array stores which cells of the grid are traversable
        // The way this grid is generated is by creating "numRectangles" rectangles and placing them at random locations of the grid

        // ----------------------------------------------------------
        // First we generate the "columns" and "rows" arrays with the sizes of the columns and arrays of the grid
        columns = new double[(int)((gridSideSize + maxRowColSize) / minRowColSize)];
        rows = new double[(int)((gridSideSize + maxRowColSize) / minRowColSize)];

        double xSize = 0;
        int d = 0;
        while (xSize < (double)gridSideSize - minRowColSize) {
            double newColSize = minRowColSize + UnityEngine.Random.Range(0f, 1f) * (maxRowColSize - minRowColSize);
            // newColSize = random.lognormvariate(math.log(4), 0.5)
            xSize += newColSize;
            columns[d++] = newColSize;
        }
        numCols = d;
        for (int i = 0; i < numCols; i++) {
            columns[i] = columns[i] / (xSize / gridSideSize); // Rescale to fit
        }

        double ySize = 0;
        d = 0;
        while (ySize < (double) gridSideSize - minRowColSize) {
            double newRowSize = minRowColSize + UnityEngine.Random.Range(0f, 1f) * (maxRowColSize - minRowColSize);
            // newColSize = random.lognormvariate(math.log(4), 0.5)
            ySize += newRowSize;
            rows[d++] = newRowSize;
        }
        numRows = d;
        for (int i = 0; i < numRows; i++) {
            rows[i] = rows[i] / (ySize / gridSideSize); // Rescale to fit
        }

        // ----------------------------------------------------------
        // Then we generate the "rectangles" that we're going to place on the grid to create the traversable cells of the grid
        rectangles = new bool[numRows][];
        for (int i = 0; i < numRows; i++) {
            rectangles[i] = new bool[numCols];
            for (int j = 0; j < numCols; j++) {
                rectangles[i][j] = false;
            }
        }
        for (int r = 0; r < numRectangles; r++) {
            // We determine the sizes of the rectangles using "thickRectangleProbability" and "thickRectangleMaxGridNum"
            // Rectangles have a (1 - thickRectangleProbability) probability of being "thin" rectangles, which means they're either (1 x N) or (N x 1) in size, where N can be anywhere between 1 and numCols or numRows (depending on orientation), randomly
            // And otherwise they are "thick" rectangles, which are either (M x N) or (N X M) where N is defined as above and M is some value between 2 and thickRectangleMaxGridNum
            int[] rectangleSize;
            if (UnityEngine.Random.Range(0f, 1f) < thickRectangleProbability) {
                if (UnityEngine.Random.Range(0f, 1f)  < horizontalRectangleProbability) {
                    rectangleSize = new int[] {UnityEngine.Random.Range(2, thickRectangleMaxGridNum + 1), UnityEngine.Random.Range(1, numCols + 1)};
                } else {
                    rectangleSize = new int[] {UnityEngine.Random.Range(1, numRows + 1), UnityEngine.Random.Range(2, thickRectangleMaxGridNum + 1)};
                }
            } else if (UnityEngine.Random.Range(0f, 1f) < horizontalRectangleProbability) {
                rectangleSize = new int[] {1, UnityEngine.Random.Range(1, numCols + 1)};
            } else {
                rectangleSize = new int[] {UnityEngine.Random.Range(1, numRows + 1), 1};
            }
            
            // Once the rectangle size has been determine, we place it randomly on the grid by picking a random starting coordinate for it
            int[] startingCoordinates = {UnityEngine.Random.Range(0, numRows), UnityEngine.Random.Range(0, numCols)};
            for (int i = 0; i < rectangleSize[0]; i++) {
                if (startingCoordinates[0] + i >= numRows) {
                    break;
                }

                for (int j = 0;  j < rectangleSize[1]; j++) {
                    if (startingCoordinates[1] + j >= numCols) {
                        break;
                    }

                    // The "rectangles" array is set to "true" for the cells that are traversable and "false" elsewhere
                    rectangles[startingCoordinates[0] + i][startingCoordinates[1] + j] = true;
                }
            }
        }
    }

    private bool[][] ValidateGrid(Vector2[][] probeCoordinates, int numProbes)
    {
        // This function explores the current generated grid starting from each of the probe coordinates and regenerates the "rectangles" variable from that probe
    
        // This is the logic:
        // - The exploration grid starts with everything at "unexplored and I'm not going to explore next" state, except for the probe cell, which will be set to "want to explore next"
        // - Then I run a pass through the entire exploration grid.
        // - If I find any -1s, I check whether they are traversable.
        // - If they are not, I mark them as non-traversable.
        // - If they are, I mark them as traversable and then any "unexplored but gonna explore next" neighbouring cells are marked as "gonna explore next"
        // - Once there are no more "gonna explore next" cells I convert the explored areas into the validated grid

        bool[][] validatedRectangles = new bool[numRows][]; // This will be the new validated grid I return at the end
        int[][] explorationRectangles = new int[numRows][]; // This will be used to perform the exploration: -1 means unexplored, 0 means unexplored but will explore next, 1 means explored
        for (int i = 0; i < numRows; i++) {
            validatedRectangles[i] = new bool[numCols];
            explorationRectangles[i] = new int[numCols];
            for (int j = 0; j < numCols; j++) {
                validatedRectangles[i][j] = false;
                explorationRectangles[i][j] = -1;
            }
        }

        bool hasValidProbe = false;
        for (int p = 0; p < numProbes; p++) {
            Vector2[] probeCoordinate = probeCoordinates[p];

            bool walkableCoord = false; // This variable keeps track of whether the space offered by the intersection of coordinates is sufficiently walkable

            double currentSize = 0;
            int[] probeRows = new int[numRows];
            int nProbeRows = 0;
            double maxCoord = 0, minCoord = gridSideSize;
            for (int i = 0; i < numRows; i++) {
                currentSize += rows[i];
                if (currentSize >= probeCoordinate[0][0] && currentSize - rows[i] <= probeCoordinate[1][0]) {
                    probeRows[nProbeRows++] = i;
                    maxCoord = Math.Max(Math.Min(currentSize, probeCoordinate[1][0]), maxCoord);
                    minCoord = Math.Min(Math.Max(currentSize - rows[i], probeCoordinate[0][0]), minCoord);
                }
            }
            if (maxCoord - minCoord >= minRowColSize - 0.01) { // Someday I will kill floating point errors
                walkableCoord = true;
            }
            
            currentSize = 0;
            int[] probeCols = new int[numCols];
            int nProbeCols = 0;
            maxCoord = 0; minCoord = gridSideSize;
            for (int j = 0; j < numCols; j++) {
                currentSize += columns[j];
                if (currentSize >= probeCoordinate[0][1] && currentSize - columns[j] <= probeCoordinate[1][1]) {
                    probeCols[nProbeCols++] = j;
                    maxCoord = Math.Max(Math.Min(currentSize, probeCoordinate[1][1]), maxCoord);
                    minCoord = Math.Min(Math.Max(currentSize - columns[j], probeCoordinate[0][1]), minCoord);
                }
            }
            if (maxCoord - minCoord >= minRowColSize - 0.01) {
                walkableCoord = true;
            }

            for (int i = 0; i < nProbeRows; i++) {
                for (int j = 0; j < nProbeCols; j++) {
                    if (rectangles[i][j]) {
                        hasValidProbe = hasValidProbe || walkableCoord; // I'll draw cells that aren't walkable if there's at least _one_ walkable location on this grid
                        explorationRectangles[i][j] = 0;
                    }
                }
            }
        }
        if (!hasValidProbe) {
            // None of the probe coordinates was accessible on this grid
            return validatedRectangles;
        }

        // Next we start exploring
        bool hasCellsToExplore = true;
        while (hasCellsToExplore) {
            hasCellsToExplore = false;
            for (int i = 0; i < numRows; i++) {
                for (int j = 0; j < numCols; j++) {
                    if (explorationRectangles[i][j] == 0) {
                        // This is a cell to explore
                        explorationRectangles[i][j] = 1; // Mark it as explored
                        if (rectangles[i][j]) {
                            // It is traversable
                            validatedRectangles[i][j] = true; // Mark it as traversable in the validated grid
                            
                            // A preceding cell is unexplored, I'll mark it as to-explore and tell the loop to restart
                            if (i > 0 && explorationRectangles[i - 1][j] == -1)  {
                                explorationRectangles[i - 1][j] = 0;
                                hasCellsToExplore = true;
                            }
                            if (j > 0 && explorationRectangles[i][j - 1] == -1)  {
                                explorationRectangles[i][j - 1] = 0;
                                hasCellsToExplore = true;
                            }

                            // A non-preceding cell is unexplored, I'll mark it as to-explore and we'll get to it in the future of the loop
                            if (i < numRows - 1 && explorationRectangles[i + 1][j] == -1)  {
                                explorationRectangles[i + 1][j] = 0;
                            }
                            if (j < numCols - 1 && explorationRectangles[i][j + 1] == -1)  {
                                explorationRectangles[i][j + 1] = 0;
                            }
                        }
                    }
                }
            }
        }

        return (validatedRectangles);
    }

    private void BuildWall (GameObject wallsOrganiser, Vector3 position, double size, string direction) {
        Vector3 rotation = new Vector3(0f, 0f, 0f);
        if (direction == East) {
            rotation = new Vector3(0f, 90f, 0f);
        } else if (direction == South) {
            rotation = new Vector3(0f, 180f, 0f);
        } else if (direction == West) {
            rotation = new Vector3(0f, 270f, 0f);
        }

        var wall = GameObject.Instantiate(wallTile);
        wall.transform.SetParent(wallsOrganiser.transform);
        var skirtingBoard = GameObject.Instantiate(skirtingBoardTile);
        wall.transform.localScale = new Vector3((float) size * 2, 1f, 1f); // multiply size by 2 because the default prefab size is 0.5
        skirtingBoard.transform.localScale = new Vector3((float) size * 2 + ((direction == North || direction == South) ? 4 * (float) skirtingBoardThickness : 0f), 1f, 1f);
        skirtingBoard.transform.SetParent(wall.transform);
        wall.transform.rotation = Quaternion.Euler(rotation.x, rotation.y, rotation.z);
        wall.transform.localPosition = position;
        
        Material uniqueMaterial = wall.GetComponent<Renderer>().material;
        uniqueMaterial.mainTextureScale = new Vector2((float) size * 2, 1f);

        uniqueMaterial = skirtingBoard.GetComponent<Renderer>().material;
        uniqueMaterial.mainTextureScale = new Vector2((float) size * 2 + ((direction == North || direction == South) ? 4 * (float) skirtingBoardThickness : 0f), 1f);
    }

    private void BuildSouthFacingWall (GameObject wallsOrganiser, Vector2 southWestCorner, Vector2 xCoordinates, double yCoordinate) {
        double size = xCoordinates[1] - xCoordinates[0];
        BuildWall(wallsOrganiser, new Vector3((float) (xCoordinates[0] + size / 2) + southWestCorner[0], 0f, (float) yCoordinate + southWestCorner[1]), size, South);
    }
    private void BuildNorthFacingWall (GameObject wallsOrganiser, Vector2 southWestCorner, Vector2 xCoordinates, double yCoordinate) {
        double size = xCoordinates[1] - xCoordinates[0];
        BuildWall(wallsOrganiser, new Vector3((float) (xCoordinates[0] + size / 2) + southWestCorner[0], 0f, (float) yCoordinate + southWestCorner[1]), size, North);
    }
    private void BuildEastFacingWall (GameObject wallsOrganiser, Vector2 southWestCorner, Vector2 yCoordinates, double xCoordinate) {
        double size = yCoordinates[1] - yCoordinates[0];
        BuildWall(wallsOrganiser, new Vector3((float) xCoordinate + southWestCorner[0], 0f, (float) (yCoordinates[0] + size / 2) + southWestCorner[1]), size, East);
    }
    private void BuildWestFacingWall (GameObject wallsOrganiser, Vector2 southWestCorner, Vector2 yCoordinates, double xCoordinate) {
        double size = yCoordinates[1] - yCoordinates[0];
        BuildWall(wallsOrganiser, new Vector3((float) xCoordinate + southWestCorner[0], 0f, (float) (yCoordinates[0] + size / 2) + southWestCorner[1]), size, West);
    }
    
    private void DrawWalls (GameObject grid, Vector2 southWestCorner, bool wallEdges = false) {
        // Let's now spawn all of the walls
        GameObject wallsOrganiser = GameObject.Instantiate(emptyGameObject);
        wallsOrganiser.transform.SetParent(grid.transform);
        wallsOrganiser.transform.localPosition = new Vector3(0f, 0f, 0f);
        wallsOrganiser.name = "Walls";

        // First the horizontal ones
        double southYCoordinate, northYCoordinate;
        double northFacingStartingXCoordinate, northFacingEndingXCoordinate;
        double southFacingStartingXCoordinate, southFacingEndingXCoordinate;
        double edgeStartingCoordinate, edgeEndingCoordinate;
        double cumulativeXCoordinate = 0, cumulativeYCoordinate = 0;

        for (int i = 0; i < numRows; i++) {
            southYCoordinate = cumulativeYCoordinate;
            cumulativeYCoordinate += rows[i];
            northYCoordinate = cumulativeYCoordinate;

            northFacingStartingXCoordinate = double.NaN;
            northFacingEndingXCoordinate = double.NaN;
            southFacingStartingXCoordinate = double.NaN;
            southFacingEndingXCoordinate = double.NaN;
            edgeStartingCoordinate = double.NaN;
            edgeEndingCoordinate = double.NaN;
            cumulativeXCoordinate = 0;
            for (int j = 0; j < numCols; j++) {
                cumulativeXCoordinate += columns[j];
                if (rectangles[i][j]) {
                    if (!Double.IsNaN(edgeStartingCoordinate)) {
                        if (i == 0) {
                            BuildSouthFacingWall (wallsOrganiser, southWestCorner, new Vector2((float) edgeStartingCoordinate, (float) edgeEndingCoordinate), southYCoordinate);
                        } else {
                            BuildNorthFacingWall (wallsOrganiser, southWestCorner, new Vector2((float) edgeStartingCoordinate, (float) edgeEndingCoordinate), northYCoordinate);
                        }
                        edgeStartingCoordinate = double.NaN;
                    }
                    
                    if (i > 0 || wallEdges) {
                        // Walls facing north
                        if (i == 0 || !rectangles[i - 1][j]) {
                            // There is a wall to the south of where I am
                            if (Double.IsNaN(northFacingStartingXCoordinate)) {
                                // Start a new wall
                                northFacingStartingXCoordinate = cumulativeXCoordinate - columns[j];
                            }
                            northFacingEndingXCoordinate = cumulativeXCoordinate;
                        } else if (!Double.IsNaN(northFacingStartingXCoordinate)) {
                            // There is not a wall to the south of where I am but I have been building a wall
                            BuildNorthFacingWall (wallsOrganiser, southWestCorner, new Vector2((float) northFacingStartingXCoordinate, (float) northFacingEndingXCoordinate), southYCoordinate);
                            northFacingStartingXCoordinate = double.NaN;
                        }
                    }
                    if (i < numRows - 1 || wallEdges) {
                        // Walls facing south
                        if (i == numRows - 1 || !rectangles[i + 1][j]) {
                            if (Double.IsNaN(southFacingStartingXCoordinate)) {
                                // Start a new wall
                                southFacingStartingXCoordinate = cumulativeXCoordinate - columns[j];
                            }
                            southFacingEndingXCoordinate = cumulativeXCoordinate;
                        } else if (!Double.IsNaN(southFacingStartingXCoordinate)) {
                            BuildSouthFacingWall (wallsOrganiser, southWestCorner, new Vector2((float) southFacingStartingXCoordinate, (float) southFacingEndingXCoordinate), northYCoordinate);
                            southFacingStartingXCoordinate = double.NaN;
                        }
                    }
                } else {
                    // Not a traversable space, end any walls we were drawing
                    if (!Double.IsNaN(northFacingStartingXCoordinate)) {
                        BuildNorthFacingWall (wallsOrganiser, southWestCorner, new Vector2((float) northFacingStartingXCoordinate, (float) northFacingEndingXCoordinate), southYCoordinate);
                        northFacingStartingXCoordinate = double.NaN;
                    }
                    if (!Double.IsNaN(southFacingStartingXCoordinate)) {
                        BuildSouthFacingWall (wallsOrganiser, southWestCorner, new Vector2((float) southFacingStartingXCoordinate, (float) southFacingEndingXCoordinate), northYCoordinate);
                        southFacingStartingXCoordinate = double.NaN;
                    }

                    if (i == 0) {
                        // I am on a non-traversable space to the south, I want to make a south-facing wall at the edge
                        if (Double.IsNaN(edgeStartingCoordinate)) {
                            // Start a new wall
                            edgeStartingCoordinate = cumulativeXCoordinate - columns[j];
                        }
                        edgeEndingCoordinate = cumulativeXCoordinate;
                    } else if (i == numRows - 1) {
                        // I am on a non-traversable space to the north, I want to make a north-facing wall at the edge
                        if (Double.IsNaN(edgeStartingCoordinate)) {
                            // Start a new wall
                            edgeStartingCoordinate = cumulativeXCoordinate - columns[j];
                        }
                        edgeEndingCoordinate = cumulativeXCoordinate;
                    } else {
                        continue;
                    }
                }
            }

            if (!Double.IsNaN(northFacingStartingXCoordinate)) {
                BuildNorthFacingWall (wallsOrganiser, southWestCorner, new Vector2((float) northFacingStartingXCoordinate, (float) northFacingEndingXCoordinate), southYCoordinate);
                northFacingStartingXCoordinate = double.NaN;
            }
            if (!Double.IsNaN(southFacingStartingXCoordinate)) {
                BuildSouthFacingWall (wallsOrganiser, southWestCorner, new Vector2((float) southFacingStartingXCoordinate, (float) southFacingEndingXCoordinate), northYCoordinate);
                southFacingStartingXCoordinate = double.NaN;
            }
            if (!Double.IsNaN(edgeStartingCoordinate)) {
                if (i == 0) {
                    BuildSouthFacingWall (wallsOrganiser, southWestCorner, new Vector2((float) edgeStartingCoordinate, (float) edgeEndingCoordinate), southYCoordinate);
                } else {
                    BuildNorthFacingWall (wallsOrganiser, southWestCorner, new Vector2((float) edgeStartingCoordinate, (float) edgeEndingCoordinate), northYCoordinate);
                }
                edgeStartingCoordinate = double.NaN;
            }
        }

        // vertical ones
        double eastXCoordinate, westXCoordinate;
        double eastFacingStartingYCoordinate, eastFacingEndingYCoordinate;
        double westFacingStartingYCoordinate, westFacingEndingYCoordinate;
        cumulativeXCoordinate = 0;
        cumulativeYCoordinate = 0;
        for (int j = 0; j < numCols; j++) {
            westXCoordinate = cumulativeXCoordinate;
            cumulativeXCoordinate += columns[j];
            eastXCoordinate = cumulativeXCoordinate;

            eastFacingStartingYCoordinate = double.NaN;
            eastFacingEndingYCoordinate = double.NaN;
            westFacingStartingYCoordinate = double.NaN;
            westFacingEndingYCoordinate = double.NaN;
            edgeStartingCoordinate = double.NaN;
            edgeEndingCoordinate = double.NaN;
            cumulativeYCoordinate = 0;
            for (int i = 0; i < numRows; i++) {
                cumulativeYCoordinate += rows[i];
                if (rectangles[i][j]) {
                    if (!Double.IsNaN(edgeStartingCoordinate)) {
                        if (j == 0) {
                            BuildWestFacingWall (wallsOrganiser, southWestCorner, new Vector2((float) edgeStartingCoordinate, (float) edgeEndingCoordinate), westXCoordinate);
                        } else {
                            BuildEastFacingWall (wallsOrganiser, southWestCorner, new Vector2((float) edgeStartingCoordinate, (float) edgeEndingCoordinate), eastXCoordinate);
                        }
                        edgeStartingCoordinate = double.NaN;
                    }

                    if (j > 0 || wallEdges) {
                        // Walls facing east
                        if (j == 0 || !rectangles[i][j - 1]) {
                            // There is a wall to the west of where I am
                            if (Double.IsNaN(eastFacingStartingYCoordinate)) {
                                // Start a new wall
                                eastFacingStartingYCoordinate = cumulativeYCoordinate - rows[i];
                            }
                            eastFacingEndingYCoordinate = cumulativeYCoordinate;
                        } else if (!Double.IsNaN(eastFacingStartingYCoordinate)) {
                            // There is not a wall to the west of where I am but I have been building a wall
                            BuildEastFacingWall (wallsOrganiser, southWestCorner, new Vector2((float) eastFacingStartingYCoordinate, (float) eastFacingEndingYCoordinate), westXCoordinate);
                            eastFacingStartingYCoordinate = double.NaN;
                        }
                    }
                    if (j < numCols - 1 || wallEdges) {
                        // Walls facing west
                        if (j == numCols - 1 || !rectangles[i][j + 1]) {
                            if (Double.IsNaN(westFacingStartingYCoordinate)) {
                                // Start a new wall
                                westFacingStartingYCoordinate = cumulativeYCoordinate - rows[i];
                            }
                            westFacingEndingYCoordinate = cumulativeYCoordinate;
                        } else if (!Double.IsNaN(westFacingStartingYCoordinate)) {
                            BuildWestFacingWall (wallsOrganiser, southWestCorner, new Vector2((float) westFacingStartingYCoordinate, (float) westFacingEndingYCoordinate), eastXCoordinate);
                            westFacingStartingYCoordinate = double.NaN;
                        }
                    }
                } else {
                    // Not a traversable space, end any walls we were drawing
                    if (!Double.IsNaN(eastFacingStartingYCoordinate)) {
                        BuildEastFacingWall (wallsOrganiser, southWestCorner, new Vector2((float) eastFacingStartingYCoordinate, (float) eastFacingEndingYCoordinate), westXCoordinate);
                        eastFacingStartingYCoordinate = double.NaN;
                    }
                    if (!Double.IsNaN(westFacingStartingYCoordinate)) {
                        double size = westFacingEndingYCoordinate - westFacingStartingYCoordinate;
                        BuildWestFacingWall (wallsOrganiser, southWestCorner, new Vector2((float) westFacingStartingYCoordinate, (float) westFacingEndingYCoordinate), eastXCoordinate);
                        westFacingStartingYCoordinate = double.NaN;
                    }

                    if (j == 0) {
                        // I am on a non-traversable space to the west, I want to make a west-facing wall at the edge
                        if (Double.IsNaN(edgeStartingCoordinate)) {
                            // Start a new wall
                            edgeStartingCoordinate = cumulativeYCoordinate - rows[i];
                        }
                        edgeEndingCoordinate = cumulativeYCoordinate;
                    } else if (j == numCols - 1) {
                        // I am on a non-traversable space to the east, I want to make a east-facing wall at the edge
                        if (Double.IsNaN(edgeStartingCoordinate)) {
                            // Start a new wall
                            edgeStartingCoordinate = cumulativeYCoordinate - rows[i];
                        }
                        edgeEndingCoordinate = cumulativeYCoordinate;
                    } else {
                        continue;
                    }
                }
            }

            if (!Double.IsNaN(eastFacingStartingYCoordinate)) {
                BuildEastFacingWall (wallsOrganiser, southWestCorner, new Vector2((float) eastFacingStartingYCoordinate, (float) eastFacingEndingYCoordinate), westXCoordinate);
                eastFacingStartingYCoordinate = double.NaN;
            }
            if (!Double.IsNaN(westFacingStartingYCoordinate)) {
                double size = westFacingEndingYCoordinate - westFacingStartingYCoordinate;
                BuildWestFacingWall (wallsOrganiser, southWestCorner, new Vector2((float) westFacingStartingYCoordinate, (float) westFacingEndingYCoordinate), eastXCoordinate);
                westFacingStartingYCoordinate = double.NaN;
            }
            if (!Double.IsNaN(edgeStartingCoordinate)) {
                if (j == 0) {
                    BuildWestFacingWall (wallsOrganiser, southWestCorner, new Vector2((float) edgeStartingCoordinate, (float) edgeEndingCoordinate), westXCoordinate);
                } else {
                    BuildEastFacingWall (wallsOrganiser, southWestCorner, new Vector2((float) edgeStartingCoordinate, (float) edgeEndingCoordinate), eastXCoordinate);
                }
                edgeStartingCoordinate = double.NaN;
            }
        }
    }

    void DrawFloorAndCeiling (GameObject grid, Vector2[] effectiveGridCorners) {
        var effectiveGridSize = effectiveGridCorners[1] - effectiveGridCorners[0];

        var floor = GameObject.Instantiate(floorTile);
        floor.name = "Floor";
        floor.transform.SetParent(grid.transform);
        floor.transform.localPosition = new Vector3(effectiveGridCorners[0][0] + effectiveGridSize[0] / 2, 0f, effectiveGridCorners[0][1] + effectiveGridSize[1] / 2);
        floor.transform.localScale = new Vector3((float) effectiveGridSize[0] * 2, 1f, (float) effectiveGridSize[1] * 2);
        Material uniqueMaterial = floor.GetComponent<Renderer>().material;
        uniqueMaterial.mainTextureScale = new Vector2((float) effectiveGridSize[0] * 2, (float) effectiveGridSize[1] * 2);

        var ceiling = GameObject.Instantiate(ceilingTile);
        ceiling.name = "Ceiling";
        ceiling.transform.SetParent(grid.transform); 
        ceiling.transform.localPosition = new Vector3(effectiveGridCorners[0][0] + effectiveGridSize[0] / 2, 3f, effectiveGridCorners[0][1] + effectiveGridSize[1] / 2);
        ceiling.transform.localScale = new Vector3((float) effectiveGridSize[0] * 2, 1f, (float) effectiveGridSize[1] * 2);
        uniqueMaterial = ceiling.GetComponent<Renderer>().material;
        uniqueMaterial.mainTextureScale = new Vector2((float) effectiveGridSize[0] * 2, (float) effectiveGridSize[1] * 2);
    }

    void DrawLights (GameObject grid, Vector2[] effectiveGridCorners) {
        // For the moment, this function will attempt to tile the entire grid with lights every "spaceBetweenLights" meters, starting at (0.5, 0.5), and not drawing any lights that would be in non-traversable areas or that would intersect with walls
        // The lights are 0.5 x 0.5
        double minPadding = 0.5;

        GameObject lightsOrganiser = GameObject.Instantiate(emptyGameObject);
        lightsOrganiser.transform.SetParent(grid.transform);
        lightsOrganiser.transform.localPosition = new Vector3(0f, 0f, 0f);
        lightsOrganiser.name = "Lights";

        Vector2 effectiveGridSize = effectiveGridCorners [1] - effectiveGridCorners[0];
        int numLightRows = (int) Math.Floor((effectiveGridSize[1] - 1) / spaceBetweenLights);
        int numLightCols = (int) Math.Floor((effectiveGridSize[0] - 1) / spaceBetweenLights);

        bool[][] drawLights = new bool[numLightRows][];
        for (int i = 0; i < numLightRows; i++) {
            drawLights[i] = new bool[numLightCols];
            for (int j = 0; j < numLightCols; j++) {
                drawLights[i][j] = false;
            }
        }

        // I will go through the grid and for each cell determine which of the lights in it are drawn
        double cumulativeY = 0;
        double cumulativeX = 0;
        for (int i = 0; i < numRows; i++) {
            cumulativeY += rows[i];
            
            cumulativeX = 0;
            for (int j = 0; j < numCols; j++) {
                double startingX = cumulativeX;
                cumulativeX += columns[j];
                if (rectangles[i][j]) {
                    if (j == 0 || !rectangles[i][j - 1]) {
                        // If I'm at the grid edge or next to a wall, I won't place any lights before the edge + 0.5m
                        startingX += minPadding * 2;
                    }
                    
                    double endingX = cumulativeX;
                    if (j == numCols - 1 || !rectangles[i][j + 1]) {
                        // If I'm at the grid edge or next to a wall, I won't place any lights before the edge + 0.5m
                        endingX -= minPadding * 2;
                    }
                    
                    double startingY = cumulativeY - rows[i]; 
                    if (i == 0 || !rectangles[i - 1][j]) {
                        // If I'm at the grid edge or next to a wall, I won't place any lights before the edge + 0.5m
                        startingY += minPadding * 2;
                    }
                    
                    double endingY = cumulativeY;
                    if (i == numRows - 1 || !rectangles[i + 1][j]) {
                        // If I'm at the grid edge or next to a wall, I won't place any lights before the edge + 0.5m
                        endingY -= minPadding * 2;
                    }

                    double x, y;
                    for (int m = 0; m < numLightRows; m++) {
                        y = minPadding + m * spaceBetweenLights;
                        if (y > endingY) {
                            break;
                        } else if (y > startingY) {
                            for (int n = 0; n < numLightCols; n++) {
                                x = minPadding + n * spaceBetweenLights;
                                if (x > endingX) {
                                    break;
                                } else if (x > startingX) {
                                    drawLights[m][n] = true;
                                }
                            }
                        }
                    }
                }
            }
        }

        GameObject light;
        int numLights = 0;
        for (int i = 0; i < numLightRows; i++) {
            for (int j = 0; j < numLightCols; j++) {
                if (drawLights[i][j]) {
                    light = GameObject.Instantiate(lightUnit);
                    light.transform.SetParent(lightsOrganiser.transform);
                    light.transform.localPosition = new Vector3(
                        effectiveGridCorners[0][0] + (float) (minPadding + j * spaceBetweenLights),
                        3.65f, // idk why the .65 is necessary here lmao TODO
                        effectiveGridCorners[0][1] + (float) (minPadding + i * spaceBetweenLights));
                    Debug.Log(numLights + " " + light.transform.localPosition);
                    light.name = "Light " + (numLights++);
                }
            }
        }

        // TODO the logic here still isn't amazing, you get weird dark corridors sometimes that logically seem like they should have lights, but the effect isn't bad so I'll keep it for now
    }
    
    bool[][] JustifyGrid () {
        // Removes "padding" of the grid (i.e. entire rows or columns at the borders that are empty)
        int startingRow = numRows, endingRow = 0;
        int startingCol = numCols, endingCol = 0;
        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j < numCols; j++) {
                if (rectangles[i][j]) {
                    if (startingRow == numRows) {
                        startingRow = i;
                    }
                    endingRow = i;

                    startingCol = Math.Min(startingCol, j);
                    endingCol = Math.Max(endingCol, j);
                }
            }
        }

        if (startingRow == 0 && endingRow == numRows - 1 && startingCol == 0 && endingCol == numCols - 1) {
            return rectangles;
        }

        numRows = endingRow - startingRow + 1;
        numCols = endingCol - startingCol + 1;
        bool[][] newRectangles = new bool[numRows][];
        for (int i = startingRow; i < numRows; i++) {
            newRectangles[i - startingRow] = new bool[numCols];
            for (int j = startingCol; j < numCols; j++) {
                newRectangles[i - startingRow][j - startingCol] = rectangles[i][j];
            }
        }

        return newRectangles;
    }
    
    Vector2[] GetEffectiveGridCornersFromSouthwest (Vector2 southWestCorner) {
        double minXCoordinate = gridSideSize, maxXCoordinate = 0, minYCoordinate = gridSideSize, maxYCoordinate = 0;
        double cumulativeXCoordinate = 0, cumulativeYCoordinate = 0;
        for (int i = 0; i < numRows; i++) {
            cumulativeYCoordinate += rows[i];
            cumulativeXCoordinate = 0;
            for (int j = 0; j < numCols; j++) {
                cumulativeXCoordinate += columns[j];
                if (rectangles[i][j]) {
                    minXCoordinate = Math.Min(minXCoordinate, cumulativeXCoordinate - columns[j]);
                    maxXCoordinate = Math.Max(maxXCoordinate, cumulativeXCoordinate);
                    
                    minYCoordinate = Math.Min(minYCoordinate, cumulativeYCoordinate - rows[i]);
                    maxYCoordinate = Math.Max(maxYCoordinate, cumulativeYCoordinate);
                }
            }
        }

        return (new Vector2[2] {
            southWestCorner + new Vector2((float) minXCoordinate, (float) minYCoordinate),
            southWestCorner + new Vector2((float) maxXCoordinate, (float) maxYCoordinate)
        });
    }

    Vector2[] GetEffectiveGridCornersFromNortheast (Vector2 northEastCorner) {
        Vector2[] corners = GetEffectiveGridCornersFromSouthwest(Vector2.zero);

        return (new Vector2[2] {
            northEastCorner - corners[0],
            northEastCorner - corners[1]
        });
    }

    Grid GenerateGrid (GameObject gridRoot, Vector2[][] probeCoordinates, int numProbes,
                      Vector2 southWestCorner, Vector2 northEastCorner,
                      bool isStartingGrid = false) {
        double traversableFraction = 0;
        while (traversableFraction < 0.3) { // Total fraction of the grid that needs to be traversable, TODO make this a parameter??
            InitializeGrid();

            if (isStartingGrid) {
                // For the initial grid, I'll forcibly add a 10x10 rectangle smack-dab in the middle
                double cumulativeSize = 0;
                int minMidRow = -1, maxMidRow = -1;
                for (int i = 0; i < numRows; i++) {
                    cumulativeSize += rows[i];
                    if (minMidRow != -1 && cumulativeSize >= gridSideSize / 2 + 5) {
                        maxMidRow = i;
                        break;
                    } else if (minMidRow == -1 && cumulativeSize >= gridSideSize / 2 - 5) {
                        minMidRow = i;
                    }
                }

                cumulativeSize = 0;
                int minMidCol = -1, maxMidCol = -1;
                for (int i = 0; i < numCols; i++) {
                    cumulativeSize += columns[i];
                    if (minMidCol != -1 && cumulativeSize >= gridSideSize / 2 + 5) {
                        maxMidCol = i;
                        break;
                    } else if (minMidCol == -1 && cumulativeSize >= gridSideSize / 2 - 5) {
                        minMidCol = i;
                    }
                }

                for (int i = minMidRow; i <= maxMidRow; i++) {
                    for (int j = minMidCol; j <= maxMidCol; j++) {
                        rectangles[i][j] = true;
                    }
                }
            }
            
            rectangles = ValidateGrid(probeCoordinates, numProbes);

            // Now validate that at least 50% of the cells are reachable
            double totalArea = numRows * numCols;
            double traversableArea = 0;
            for (int i = 0; i < numRows; i++) {
                for (int j = 0; j < numCols; j++) {
                    if (rectangles[i][j]) {
                        traversableArea += 1;
                    }
                }
            }

            traversableFraction = traversableArea / totalArea;
        }

        Vector2[] effectiveGridCorners;
        if (southWestCorner != Vector2.zero) {
            effectiveGridCorners = GetEffectiveGridCornersFromSouthwest(southWestCorner);
        } else {
            effectiveGridCorners = GetEffectiveGridCornersFromNortheast(southWestCorner);
        }
        
        rectangles = JustifyGrid();
        DrawFloorAndCeiling(gridRoot, effectiveGridCorners);
        DrawLights(gridRoot, effectiveGridCorners);
        DrawWalls(gridRoot, effectiveGridCorners[0]);

        Grid grid = (Grid)gridRoot.AddComponent(typeof(Grid));
        grid.initialize(gridRoot, effectiveGridCorners);
        grid.GenerateExits(rectangles, rows, numRows, columns, numCols);
        return grid;
    }

    Grid GenerateGrid (GameObject gridRoot) {
        return GenerateGrid(
            gridRoot,
            new Vector2[1][] {
                new Vector2[2] {
                    new Vector2((float) ((gridSideSize - minRowColSize) / 2), (float) ((gridSideSize - minRowColSize) / 2)),
                    new Vector2((float) ((gridSideSize + minRowColSize) / 2), (float) ((gridSideSize + minRowColSize) / 2))
                }
            },
            1,
            new Vector2((float) -gridSideSize / 2, (float) -gridSideSize / 2), Vector2.zero,
            true);
    }

    Grid GenerateNorthNeighbour (Grid originGrid) {
        if (originGrid.northGrid != null) {
            // Don't generate if I already exist
            return originGrid.northGrid;
        }

        GameObject gridRoot = GameObject.Instantiate(emptyGameObject);
        gridRoot.transform.SetParent(transform);
        gridRoot.transform.localPosition = Vector3.zero;

        GridExit[] northExits = originGrid.GetNorthExits();
        Vector2[][] probeCoordinates = new Vector2[northExits.Length][];
        for (int i = 0; i < northExits.Length; i++) {
            Vector2[] exit = northExits[i].ToVector2();
            probeCoordinates[i] = new Vector2[2] {
                new Vector2(exit[0][0], 0f),
                new Vector2(exit[1][0], 0f)
            };
        }

        Grid newGrid = GenerateGrid (gridRoot, probeCoordinates, northExits.Length, new Vector2((float) -gridSideSize / 2, (float) -gridSideSize / 2), Vector2.zero);

        originGrid.northGrid = newGrid;

        gridRoot.transform.localPosition = originGrid.transform.localPosition + new Vector3(0f, 0f, (originGrid.GetVerticalSize() + newGrid.GetVerticalSize()) / 2);

        return newGrid;
    }

    void Start()
    {
        // set up the first grid
        GameObject gridRoot = GameObject.Instantiate(emptyGameObject);
        gridRoot.name = "grid 0";
        gridRoot.transform.SetParent(transform);
        gridRoot.transform.position = transform.position;

        currentGrid = GenerateGrid(gridRoot);
    }
}
