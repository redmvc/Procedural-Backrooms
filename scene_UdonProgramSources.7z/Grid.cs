﻿
using UdonSharp;
using UnityEngine;
using VRC.SDKBase;
using VRC.Udon;
using System;
public class Grid : UdonSharpBehaviour
{
    public Grid northGrid;
    public Grid southGrid;
    public Grid eastGrid;
    public Grid westGrid;

    private GameObject root;
    private Vector2[] gridCorners;
    private GridExit[] exits;
    private int numExits;

    void Start() {}

    public void initialize(GameObject root, Vector2[] gridCorners) {
        this.root = root;
        this.gridCorners = gridCorners;

        this.northGrid = null;
        this.southGrid = null;
        this.eastGrid = null;
        this.westGrid = null;

        this.exits = null;
        this.numExits = -1;
    }

    public void destroy() {
        if (northGrid != null) {
            northGrid.southGrid = null;
        }
        if (southGrid != null) {
            southGrid.northGrid = null;
        }
        if (eastGrid != null) {
            eastGrid.westGrid = null;
        }
        if (westGrid != null) {
            westGrid.eastGrid = null;
        }

        GameObject.Destroy(root);
    }

    public void AddExit(GridExit newExit) {
        if (numExits == -1) {
            numExits = 1;
            exits = new GridExit[1] {newExit};
        } else {
            numExits += 1;
            GridExit[] newExitList = new GridExit[numExits];
            for (int i = 0; i < numExits - 1; i++) {
                newExitList[i] = exits[i];
            }
            newExitList[numExits] = newExit;

            exits = newExitList;
        }
    }

    public void AddExit(Vector2 start, Vector2 end) {
        GridExit newExit = new GridExit();
        newExit.initialize(start, end);
        AddExit(newExit);
    }

    public GridExit GetExit(int i) {
        if (i >= 0 && i < numExits) {
            return exits[i];
        }
        return null;
    }

    public GridExit[] GetExits() {
        return exits;
    }

    public GridExit[] GetNorthExits() {
        int numFilteredExits = 0;
        for (int i = 0; i < numExits; i++) {
            if (exits[i].horizontal && exits[i].fixedCoord > 0) {
                numFilteredExits++;
            }
        }

        GridExit[] filteredExits = new GridExit[numFilteredExits];
        int j = 0;
        for (int i = 0; i < numExits; i++) {
            if (exits[i].horizontal && exits[i].fixedCoord > 0) {
                filteredExits[j++] = exits[i];
            }
        }
        return filteredExits;
    }

    public GridExit[] GetSouthExits() {
        int numFilteredExits = 0;
        for (int i = 0; i < numExits; i++) {
            if (exits[i].horizontal && exits[i].fixedCoord <= 0) {
                numFilteredExits++;
            }
        }

        GridExit[] filteredExits = new GridExit[numFilteredExits];
        int j = 0;
        for (int i = 0; i < numExits; i++) {
            if (exits[i].horizontal && exits[i].fixedCoord <= 0) {
                filteredExits[j++] = exits[i];
            }
        }
        return filteredExits;
    }

    public GridExit[] GetEastExits() {
        int numFilteredExits = 0;
        for (int i = 0; i < numExits; i++) {
            if (!exits[i].horizontal && exits[i].fixedCoord > 0) {
                numFilteredExits++;
            }
        }

        GridExit[] filteredExits = new GridExit[numFilteredExits];
        int j = 0;
        for (int i = 0; i < numExits; i++) {
            if (!exits[i].horizontal && exits[i].fixedCoord > 0) {
                filteredExits[j++] = exits[i];
            }
        }
        return filteredExits;
    }

    public GridExit[] GetWestExits() {
        int numFilteredExits = 0;
        for (int i = 0; i < numExits; i++) {
            if (!exits[i].horizontal && exits[i].fixedCoord <= 0) {
                numFilteredExits++;
            }
        }

        GridExit[] filteredExits = new GridExit[numFilteredExits];
        int j = 0;
        for (int i = 0; i < numExits; i++) {
            if (!exits[i].horizontal && exits[i].fixedCoord <= 0) {
                filteredExits[j++] = exits[i];
            }
        }
        return filteredExits;
    }

    public Vector2[][] GetExitsVector2() {
        Vector2[][] exitsVector2 = new Vector2[numExits][];
        for (int i = 0; i < numExits; i++) {
            exitsVector2[i] = exits[i].ToVector2();
        }

        return exitsVector2;
    }

    public float GetVerticalSize() {
        return gridCorners[1][1] - gridCorners[0][1];
    }

    public float GetHorizontalSize() {
        return gridCorners[1][0] - gridCorners[0][0];
    }

    public void GenerateExits (bool[][] rectangles, double[] rows, int numRows, double[] columns, int numCols) {
        // generate a list of exits from the bool grid
        // this should only be called when the grid is current

        // Horizontal exits
        float fixedCoord = 0;
        for (int i = 0; i < numRows; i++) {
            fixedCoord += (float) rows[i];
        }

        double cumulativeCoord = 0;
        double startingZeroCoord = double.NaN;
        double startingMaxCoord = double.NaN;
        for (int j = 0; j < numCols; j++) {
            cumulativeCoord += columns[j];

            if (rectangles[0][j]) {
                if (Double.IsNaN(startingZeroCoord)) {
                    startingZeroCoord = cumulativeCoord - columns[j];
                }
            } else if (!Double.IsNaN(startingZeroCoord)) {
                this.AddExit(new Vector2(0f, (float) startingZeroCoord), new Vector2(0f, (float) cumulativeCoord));
                startingZeroCoord = double.NaN;
            }

            if (rectangles[numRows - 1][j]) {
                if (Double.IsNaN(startingMaxCoord)) {
                    startingMaxCoord = cumulativeCoord - columns[j];
                }
            } else if (!Double.IsNaN(startingMaxCoord)) {
                this.AddExit(new Vector2(fixedCoord, (float) startingMaxCoord), new Vector2(fixedCoord, (float) cumulativeCoord));
                startingMaxCoord = double.NaN;
            }
        }

        // Vertical exits
        fixedCoord = 0;
        for (int j = 0; j < numCols; j++) {
            fixedCoord += (float) columns[j];
        }

        cumulativeCoord = 0;
        startingZeroCoord = double.NaN;
        startingMaxCoord = double.NaN;
        for (int i = 0; i < numRows; i++) {
            cumulativeCoord += rows[i];

            if (rectangles[i][0]) {
                if (Double.IsNaN(startingZeroCoord)) {
                    startingZeroCoord = cumulativeCoord - rows[i];
                }
            } else if (!Double.IsNaN(startingZeroCoord)) {
                this.AddExit(new Vector2((float) startingZeroCoord, 0f), new Vector2((float) cumulativeCoord, 0f));
                startingZeroCoord = double.NaN;
            }

            if (rectangles[i][numCols - 1]) {
                if (Double.IsNaN(startingMaxCoord)) {
                    startingMaxCoord = cumulativeCoord - rows[i];
                }
            } else if (!Double.IsNaN(startingMaxCoord)) {
                this.AddExit(new Vector2((float) startingMaxCoord, fixedCoord), new Vector2((float) cumulativeCoord, fixedCoord));
                startingMaxCoord = double.NaN;
            }
        }
    }
}
